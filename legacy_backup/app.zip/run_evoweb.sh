#!/bin/bash
eval "$(/root/.local/share/fnm/fnm env --use-on-cd --shell bash)"
#echo $PATH
node --inspect=0.0.0.0:9229 server.js /opt/scripts/evohome/webScheduler/server.js
